/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

/**
 *
 * @author Administrator
 */
import com.sun.jna.platform.win32.WinBase;
import com.sun.jna.platform.win32.WinDef;
import com.sun.jna.platform.win32.WinNT;
import java.io.File;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;
import org.Kernel32;
public class FileCheckerClass {
    
	static HashMap<String,FileProperties> hMap1 = new HashMap<String,FileProperties>();
	static HashMap<String,FileProperties> hMap2 = new HashMap<String,FileProperties>();
        static String FileId="" ;
        static FileProperties fpObj = null;
        static String Query =  "";
        static String fname = "";
    ///begin of the creatingMd5 file method
    public static String creatingMd5(String path) throws NoSuchAlgorithmException{         
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(path.getBytes());
        
        byte byteData[] = md.digest(); 
        //convert the byte to hex format method 1
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < byteData.length; i++) {
         sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
        }
     
        System.out.println("Digest(in hex format):: " + sb.toString());
        return sb.toString();
    }            
    ///End of the creatingMd5 file method
    
    /////////////////////////////////////////////////////////////////////////////////////////////////////
//    recursive method for the Depth fisrt Search  begins    
    	static void RecursivePrint(File[] arr,int index) 
	{
				try{
					// terminate condition
				if(index == arr.length)
					return;
				
				 
				// System.out.println(); 
				
				// for files
				if(arr[index].isFile())
					{
						// System.out.println(arr[index].getName()+" absolute path : "+arr[index].getAbsolutePath()+" size "+arr[index].length()+"hasCode of  the file "+arr[index].hashCode()+"\n");
						//System.out.println("last modified "+arr[index].lastModified());
//						objectId = objectIdFetcher(arr[index].getAbsolutePath());
//						fpObj = fpObjectCreater(arr[index]);

						// System.out.println(" objectId "+objectId+" file ");

						hMap2.put(FileIdGetter(arr[index]), fpObj);
					}
				// for sub-directories
				else if(arr[index].isDirectory())
				{
					// System.out.println("[" + arr[index].getName() + "]");

					// System.out.println(arr[index].getName()+" absolute path : "+arr[index].getAbsolutePath()+" size "+arr[index].length()+"hasCode of  the file "+arr[index].hashCode()+"\n");
						// System.out.println("last modified "+arr[index].lastModified());
//					 	objectId = objectIdFetcher(arr[index].getAbsolutePath());
						fpObj = fpObjectCreater(arr[index]);

						// System.out.println(" objectId "+objectId+" folder ");
						hMap2.put(FileIdGetter(arr[index]), fpObj);



					// recursion for sub-directories
					RecursivePrint(arr[index].listFiles(), 0);
				}
				
				// recursion for main directory
				RecursivePrint(arr,++index);
				}
				catch(Exception e){
					String s[]= e.toString().split(":");
								System.out.println("Error "+ s[1]);
				}
	}

///////////// end method     
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        	static FileProperties fpObjectCreater(File fp) throws IOException{

			fpObj = new FileProperties();
			 
			try{
				// System.out.println(" name "+fp.getName()+" parent "+fp.getParentFile().getName()+" size "+fp.length());
				// fp.getParentFile().getName()
			fpObj.setParentName(fp.getParent());
			fpObj.setParentObj(FileIdGetter(fp.getParentFile()));
			fpObj.setName(fp.getName());
				// System.out.println(" file last modified "+fp.lastModified()+" name "+fp.getName());
			// fpObj.setSize(fp.length());
			fpObj.setLastModifiedTime(fp.lastModified()+"");
			}
			catch(Exception e){

					String s[]= e.toString().split(":");
								System.out.println("Error "+ s[1]);
			}
		return fpObj;	
	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public static void  main(String []args){
       String folderPath=null;
        while(true){
        try{
            Scanner sin = new Scanner(System.in);
            while(true){
              folderPath = sin.nextLine();
            // file creation and checking  for the root folder 
            File maindir = new File(folderPath);
                if(maindir.isDirectory()){
                    break;
                    }
                else{
                    System.out.println("Please enter the Valid Folder path\n");
                }
            } // end of the inner looop
            
            /*
                //////////////////////// 
                This is for the Folder table name information storing in databse
                This table consist of the path MD5 and foldertable for unique 
            */
               try {    
                   int count =0;
                            try{
                                   Class.forName("com.mysql.jdbc.Driver");
                                 }
                                 catch(ClassNotFoundException r){
                                         r.printStackTrace();
                                 }
                                         Connection c= DriverManager.getConnection("jdbc:mysql://localhost:3306/fdatabase","root","root");
                                         Statement st= c.createStatement();
            ResultSet resultSet = c.getMetaData().getCatalogs();

        while (resultSet.next()) {

          String databaseName = resultSet.getString(1);
             System.out.println(" databases "+databaseName);
        }
        resultSet.close();
           
                                         
                                        // creating table if not exist
                                                    
                                                    st.execute("create table if not exists foldertable ( fpath varchar(40) primary key , ftname varchar(20) not null unique )");
                                         ResultSet rs=st.executeQuery("select count(*) from foldertable");
                                         if(rs.next()){
                                             count = Integer.parseInt(rs.getString(1));
                                         
                                         }
                                          count++;
                                          
                                        String fpath = creatingMd5(folderPath);
                                        Query = "select fpath from foldertable where fpath =''"+fpath+"''";
                                        if(!st.executeQuery(Query).next()){
                                                                               
                                        while(true){
                                            String s =Math.random()+"";
                                        fname = "folder"+s.substring(5);
                                        // insering Query                                         
                                          Query ="insert into foldertable values('"+fpath+"','"+fname+"')";
                                                if(st.execute(Query)){
                                                    break;
                                                }
                                        }
                                        ////////// creating the folder table  
                                            Query ="create table if not exists "+fname+"(parentName TEXT(200000), parentObj varchar(50), name varchar(256), modifiedValue varchar(50))";
                                            st.execute(Query);
                                            /* inserting the data into  table */
                                                
                                            String key ="";
                                           
//                                            Query ="inset into "+fname+"values("+ +")"; 
                                            
                                            
                                            ///////////end of th creating the folder table 
                                        } 
                                        else{
                                                
                                        }
                                        
                                        
                                         
                                         
               }
               catch(Exception e){
                   
               }
            
            
            //to break the main loop 
            break;
        }
        catch(Exception e){
            String s[]= e.toString().split(":");
	    System.out.println( "\n Invalid Input \n Error : "+s[1]+"\n Please Give Valid Path\n");
        }
//    return 
       }
       
       }
    // Method for the file id Getter
    static String FileIdGetter(File file){
         
        final int FILE_SHARE_READ = (0x00000001);
         
        final int OPEN_EXISTING = (3);
        final int GENERIC_READ = (0x80000000);
        final int FILE_FLAG_BACKUP_SEMANTICS = 0x02000000;
 

        WinBase.SECURITY_ATTRIBUTES attr = null;
        Kernel32.BY_HANDLE_FILE_INFORMATION lpFileInformation = new Kernel32.BY_HANDLE_FILE_INFORMATION();
//        _FILE_ID_INFO fileId = new _FILE_ID_INFO(); // for the file id reference 
        
        WinNT.HANDLE hFile = null;
        WinDef.LPVOID lpInformation = null;
        Kernel32._FILE_INFO_BY_HANDLE_CLASS info = null;
        Scanner sin = new Scanner(System.in);
 
//        File file = new File(path);
        hFile = com.sun.jna.platform.win32.Kernel32.INSTANCE.CreateFile(file.toString(), GENERIC_READ, FILE_SHARE_READ, attr, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, null);

//        HANDLE handle = com.sun.jna.platform.win32.Kernel32.INSTANCE.CreateFile(file.toString(), GENERIC_READ, FILE_SHARE_READ, SECURITY_ATTRIBUTES, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, null);
        System.out.println("CreateFile last error:" + com.sun.jna.platform.win32.Kernel32.INSTANCE.GetLastError()); 
        {

            org.Kernel32.INSTANCE.GetFileInformationByHandle(hFile, lpFileInformation);
            
            org.Kernel32.INSTANCE.GetFileInformationByHandleEx(hFile, info , lpInformation, null);
            System.out.println("CREATION TIME: " + WinBase.FILETIME.filetimeToDate(lpFileInformation.ftCreationTime.dwHighDateTime, lpFileInformation.ftCreationTime.dwLowDateTime));

            System.out.println("VOLUME SERIAL NO.: " + Integer.toHexString(lpFileInformation.dwVolumeSerialNumber.intValue()));
            System.out.println("Last access time : " +WinBase.FILETIME.filetimeToDate(lpFileInformation.ftLastAccessTime.dwHighDateTime , lpFileInformation.ftLastAccessTime.dwLowDateTime) );
            System.out.println("FILE INDEX HIGH: " + lpFileInformation.nFileIndexHigh);
            System.out.println("FILE INDEX LOW: " + lpFileInformation.nFileIndexLow);
            System.out.println(" unique id is "+lpFileInformation.nFileIndexHigh+lpFileInformation.nFileIndexLow+ Integer.toHexString(lpFileInformation.dwVolumeSerialNumber.intValue()));
//            System.out.println("FILE ID : "+lpFileInformation.FileId.Identifier.toString());
//            System.out.println("VOULME ID : "+lpFileInformation.VolumeSerialNumber);

            System.out.println("GetFileInformationByHandle last error:" + com.sun.jna.platform.win32.Kernel32.INSTANCE.GetLastError());
        }

        com.sun.jna.platform.win32.Kernel32.INSTANCE.CloseHandle(hFile);

        System.out.println("CloseHandle last error:" + com.sun.jna.platform.win32.Kernel32.INSTANCE.GetLastError());

    return ""+lpFileInformation.nFileIndexHigh+lpFileInformation.nFileIndexLow+ Integer.toHexString(lpFileInformation.dwVolumeSerialNumber.intValue());
    }
    
} // End of the class

