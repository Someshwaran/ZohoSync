/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

/**
 *
 * @author ELCOT
 */class FileProperties   {
	private String parentName;
	private String parentObj;
	// private Long size;
	private String name;
	private String lastModifiedTime;

	////////////// getter() and Setter()/////////
	void setParentObj(String obj){
		this.parentObj = obj;
	}
	void setParentName(String name){
		this.parentName = name;
	}

	void setLastModifiedTime(String time){
		this.lastModifiedTime = time;
	}

	void setName(String name){
		this.name = name;
	}

	String getLastModifiedTime(){
		return this.lastModifiedTime;
	}
	String getParentName(){
		return this.parentName;
	}

	String getName(){
		return this.name;
	}
	String getParentObj(){
		return this.parentObj;
	}
}
