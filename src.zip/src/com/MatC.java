/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

/**
 *
 * @author Administrator
 */

public class MatC {
    public static void main(String[] args) {
        String ra = Math.random()+"";
        System.out.println(" random number "+ra.substring(0,6)+" length "+ra.length());
             System.out.println(" rando"+(Math.random()));
         }   
}
