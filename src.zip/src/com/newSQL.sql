/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Administrator
 * Created: Jul 14, 2018
 */
create database fdatabase;
create table foldertable( fpath varchar(40) primary key , ftname varchar(20) );
