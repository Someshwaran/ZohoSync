/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org;

/**
 *
 * @author Administrator
 */
import com.sun.jna.platform.win32.Kernel32;
import com.sun.jna.platform.win32.WinBase;
import com.sun.jna.platform.win32.WinBase.FILETIME;
import com.sun.jna.platform.win32.WinDef.LPVOID;
import com.sun.jna.platform.win32.WinNT.HANDLE;
import java.io.File;
import java.util.Scanner;

import org.Kernel32.BY_HANDLE_FILE_INFORMATION;
import org.Kernel32._FILE_INFO_BY_HANDLE_CLASS;
//import org.Kernel32._FILE_ID_INFO;

public class FileTest {

    /**
     * @param args
     */
//        private static int GENERIC_READ = 0x80000000;
//        private static int FILE_SHARE_READ = 0x00000001;
//        private static WinBase.SECURITY_ATTRIBUTES SECURITY_ATTRIBUTES = null;
//        private static int OPEN_EXISTING = 3;
//        private static int FILE_FLAG_BACKUP_SEMANTICS = 0x02000000;
    public static void main(String[] args) {
        //http://msdn.microsoft.com/en-us/library/windows/desktop/aa363858%28v=vs.85%29.aspx
        final int FILE_SHARE_READ = (0x00000001);
         
        final int OPEN_EXISTING = (3);
        final int GENERIC_READ = (0x80000000);
        final int FILE_FLAG_BACKUP_SEMANTICS = 0x02000000;
 

        WinBase.SECURITY_ATTRIBUTES attr = null;
        BY_HANDLE_FILE_INFORMATION lpFileInformation = new BY_HANDLE_FILE_INFORMATION();
//        _FILE_ID_INFO fileId = new _FILE_ID_INFO(); // for the file id reference 
        
        HANDLE hFile = null;
        LPVOID lpInformation = null;
        _FILE_INFO_BY_HANDLE_CLASS info = null;
        Scanner sin = new Scanner(System.in);
//args[0] "C:\\Users\\Administrator\\Desktop\\newSrcCode1.txt" "D:\Development software\downloader\eagleget_2.0.4.28 texy.txt"
String path = sin.nextLine();
        File file = new File(path);
        hFile = com.sun.jna.platform.win32.Kernel32.INSTANCE.CreateFile(file.toString(), GENERIC_READ, FILE_SHARE_READ, attr, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, null);

//        HANDLE handle = com.sun.jna.platform.win32.Kernel32.INSTANCE.CreateFile(file.toString(), GENERIC_READ, FILE_SHARE_READ, SECURITY_ATTRIBUTES, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, null);
        System.out.println("CreateFile last error:" + Kernel32.INSTANCE.GetLastError());

        //if (hFile. != -1)
        {

            org.Kernel32.INSTANCE.GetFileInformationByHandle(hFile, lpFileInformation);
            
            org.Kernel32.INSTANCE.GetFileInformationByHandleEx(hFile, info , lpInformation, null);
            System.out.println("CREATION TIME: " + FILETIME.filetimeToDate(lpFileInformation.ftCreationTime.dwHighDateTime, lpFileInformation.ftCreationTime.dwLowDateTime));

            System.out.println("VOLUME SERIAL NO.: " + Integer.toHexString(lpFileInformation.dwVolumeSerialNumber.intValue()));
            System.out.println("Last access time : " +FILETIME.filetimeToDate(lpFileInformation.ftLastAccessTime.dwHighDateTime , lpFileInformation.ftLastAccessTime.dwLowDateTime) );
            System.out.println("FILE INDEX HIGH: " + lpFileInformation.nFileIndexHigh);
            System.out.println("FILE INDEX LOW: " + lpFileInformation.nFileIndexLow);
            System.out.println(" unique id is "+lpFileInformation.nFileIndexHigh+lpFileInformation.nFileIndexLow+ Integer.toHexString(lpFileInformation.dwVolumeSerialNumber.intValue()));
//            System.out.println("FILE ID : "+lpFileInformation.FileId.Identifier.toString());
//            System.out.println("VOULME ID : "+lpFileInformation.VolumeSerialNumber);

            System.out.println("GetFileInformationByHandle last error:" + Kernel32.INSTANCE.GetLastError());
        }

        Kernel32.INSTANCE.CloseHandle(hFile);

        System.out.println("CloseHandle last error:" + Kernel32.INSTANCE.GetLastError());

    }

}
